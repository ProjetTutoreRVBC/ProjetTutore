angular
	.module('exoCinema')
	.filter('genre',['MOVIE_GENRES',function(MOVIE_GENRES){

	return function(id){
		/*
		 * ecrire un filtre qui permet 
		 * d'afficher le genre en fonction de l'id
		 * a l'aide du tableau MOVIE_GENRES,
		 * constatnte de l'application
		 * */
		}
}])

