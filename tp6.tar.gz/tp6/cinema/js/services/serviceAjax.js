angular.module('exoCinema')
	.factory('serviceAjax',['$http','$q', function ($http, $q) {

		var apikey="0c751d57eda16f66a81a9595fb3211f6"; // votre clé MOVIE DB
		var urlBase = "https://api.themoviedb.org/3";

		var service = {
			getListMovies:getListMovies
		};


		function getListMovies (page,type,query){
			switch(type){
			case 'search':
			    url = urlBase+"/search/movie?api_key="+apikey+"&language=fr-FR&query="+query+"&page="+page;
			    break;
			case 'popular' : 
			    url = urlBase+"/movie/popular?api_key="+apikey+"&language=fr-FR&page="+page;
			    break;
			default:
			    url = urlBase+"/movie/popular?api_key="+apikey+"&language=fr-FR&page="+page;
			}
			return $http(
				{
					method : "GET",
					url : url				
				}
			);

		}

		return service;
	}])

