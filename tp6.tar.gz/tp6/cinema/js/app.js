'use strict';

angular
	.module('exoCinema', [
		'ngRoute','jkAngularRatingStars'
	])
	.config(function ($routeProvider,$locationProvider) {
		$routeProvider
			.when('/', {
				templateUrl: 'views/default.html',
				controller: 'defaultCtrl'
			})
			.otherwise({
				redirectTo: '/'
			});
		$locationProvider.hashPrefix('');
		/*	  .html5Mode(true);*/
	});

