angular.module('exoCinema')
	.controller('defaultCtrl', function ($scope, DEFAULT_MOVIE_TYPE,MOVIE_TYPES,$routeParams,serviceAjax) {

	    $scope.films = [];
	    $scope.currentPage=1;
	    $scope.totalPages=null;
	    $scope.loading=false;
	    $scope.tri = 'title';
	    $scope.order = true;
	    $scope.querySearch=null;
	    $scope.type = DEFAULT_MOVIE_TYPE.name; 
	    $scope.types = MOVIE_TYPES; 
	    
	    $scope.getMovies = function(){
		$scope.loading=true;
		serviceAjax
		    .getListMovies($scope.currentPage,$scope.type,$scope.querySearch)
		    .then(function(data){
			console.log(data);
			$scope.currentPage=data.data.page;
			$scope.films=data.data.results;
			$scope.totalPages=data.data.total_pages;
			$scope.loading=false;
		    });
	    }
	    
	    /* fonctions à copmléter à utiliser
	     * dans la vue */
	    
	    $scope.search=function(){
		$scope.currentPage=1;
		$scope.type="search";
		$scope.getMovies();
	    }
	    
	    $scope.sortType=function(type){
		$scope.currentPage=1;
                $scope.type=type;
		$scope.querySearch=null;
                $scope.getMovies();
	    }

	    $scope.sortRate=function(order){
	    }
	    
	    $scope.sortTitle=function(order){
		$scope.type=order;
                $scope.currentPage=1;
                $scope.getMovies();
	    }
	    
	    $scope.decPage=function(){
		if($scope.currentPage > 1){
		    $scope.currentPage--;
		}
	    }
	    
	    $scope.incPage=function(){
		if($scope.currentPage <= 985 ){
		    $scope.currentPage++;
		}
	    }
	    
	    $scope.$watch("page",function(){
		$scope
		    .getMovies($scope.page,$scope.type);
	    })
	    $scope.changeType = function(type){
	    }

	    $scope
		.getMovies();
	})
